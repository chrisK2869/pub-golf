# ⛳ Pub Golf App

A full-featured pub golf scoring PWA (Progressive Web App).

## Quick Start

### Open directly
Open `index.html` in any modern browser. No server needed.

### Install as Android app (recommended)
1. Open `index.html` in **Chrome on Android**
2. Tap the **"⛳ Add Pub Golf to Home Screen"** banner  
   OR tap the three-dot menu → "Add to Home screen"
3. The app installs with the golf ball icon — works offline!

### Host on GitHub Pages
1. Push this entire folder to a GitHub repo
2. Go to **Settings → Pages → Branch: main → / (root)**
3. Visit `https://yourusername.github.io/your-repo/`
4. Install from Chrome on Android as PWA

## Features
⛳ 1–18 holes · 👥 Up to 10 players · 🍺 Per-player drinks  
📊 Traditional scorecard symbols · 🎰 Side bets · 📷 Photos & videos  
💾 Auto-save & continue · 🏆 Full leaderboard · 📱 Full offline support

## Files
| File | Purpose |
|------|---------|
| `index.html` | The complete self-contained app |
| `manifest.json` | PWA manifest (app name, icons, colours) |
| `sw.js` | Service worker (offline caching) |
| `icon-*.png` | App icons (72px–512px) |
| `favicon.ico` | Browser tab icon |
